// src/app/components/productdetail/RecommendationSection.tsx
import React from "react";
import Image from "next/image";

const RecommendationSection = () => {
  return (
    <section className="mt-12">
      <h2 className="text-2xl font-bold text-orange-500 text-center mb-6">OUR RECOMMENDATION</h2>
      
      {/* Kontainer dengan scroll horizontal */}
      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
        {/* Produk Rekomendasi 1 */}
        <div className="min-w-[200px] bg-white rounded-lg shadow-md p-4 flex-shrink-0">
          <Image
            src="/product/GranolaPuffs.png"
            alt="Granola Puffs Chocolate Vanilla"
            width={150}
            height={150}
            className="mx-auto"
          />
          <p className="text-center mt-2 text-sm font-medium">
            GRANOLA PUFS Chocolate Vanilla
          </p>
        </div>

        {/* Produk Rekomendasi 2 */}
        <div className="min-w-[200px] bg-white rounded-lg shadow-md p-4 flex-shrink-0">
          <Image
            src="/product/GranolaChocolate.png"
            alt="Granola Chocolate Vanilla"
            width={150}
            height={150}
            className="mx-auto"
          />
          <p className="text-center mt-2 text-sm font-medium">
            GRANOLA Chocolate Vanilla
          </p>
        </div>

        {/* Produk Rekomendasi 3 */}
        <div className="min-w-[200px] bg-white rounded-lg shadow-md p-4 flex-shrink-0">
          <Image
            src="/product/GranolaBanana.png"
            alt="Granola Banana"
            width={150}
            height={150}
            className="mx-auto"
          />
          <p className="text-center mt-2 text-sm font-medium">
            GRANOLA Chocolate Banana
          </p>
        </div>
      </div>
    </section>
  );
};

export default RecommendationSection;