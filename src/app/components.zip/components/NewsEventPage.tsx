"use client";

import React from "react";

// Interface untuk artikel
interface Article {
  id: number;
  title: string;
  image: string;
  source: string;
  date: string;
}

const NewsEventPage: React.FC = () => {
  // Artikel utama
  const mainArticle = {
    id: 1,
    title:
      'Smooth Fasting & Stable Blood Sugar: Follow This Eating Pattern for Suhoor & Iftar!',
    image: 'main-article.jpg',
    source: 'Yava',
    date: '25 March 2025',
  };

  // Artikel pendukung
  const supportingArticles = [
    {
      id: 2,
      title: 'Stable Blood Sugar for Health & Energy While Breastfeeding',
      image: 'article1.jpg',
      source: 'Yava',
      date: '17 January 2025',
    },
    {
      id: 3,
      title: 'The World’s Best Diet: Low Glycemic Index for Gut Health',
      image: 'article2.jpg',
      source: 'Yava',
      date: '06 December 2024',
    },
    {
      id: 4,
      title: 'Positive Thinking for a Healthier Heart!',
      image: 'article3.jpg',
      source: 'Yava',
      date: '12 November 2024',
    },
  ];

  // Artikel rekomendasi
  const recommendedArticles = [
    {
      id: 5,
      title: 'Normal Blood Sugar: Why It Matters for Your Health',
      image: 'recommended1.jpg',
      source: 'Yava',
      date: '10 October 2024',
    },
    {
      id: 6,
      title: 'High-Fiber Healthy Snacks to Support Digestive Health',
      image: 'recommended2.jpg',
      source: 'Yava',
      date: '08 September 2024',
    },
    {
      id: 7,
      title: 'What is the Glycemic Index? A Complete Guide to Better Health',
      image: 'recommended3.jpg',
      source: 'Yava',
      date: '01 August 2024',
    },
    {
      id: 8,
      title: 'Smart Healthy Living for a Busy Lifestyle!',
      image: 'recommended4.jpg',
      source: 'Yava',
      date: '20 July 2024',
    },
    {
      id: 9,
      title: 'Low-Glycemic Diet: The Secret to a Healthy Weight',
      image: 'recommended5.jpg',
      source: 'Yava',
      date: '15 June 2024',
    },
    {
      id: 10,
      title: 'Take a Walk After Meals: A Simple Trick to Control Blood Sugar',
      image: 'recommended6.jpg',
      source: 'Yava',
      date: '05 May 2024',
    },
  ];

  return (
    <div className="news-event-page">
      {/* Embedded CSS */}
      <style>{`
        .news-event-page {
          font-family: Arial, sans-serif;
          background-color: #f9f9f9; /* Latar belakang utama */
        }

        body {
          margin: 0;
          padding: 0;
          overflow-x: hidden; /* Menghindari scroll horizontal */
          background-color: #f9f9f9; /* Pastikan latar belakang body sesuai */
        }

        .container {
          max-width: 1200px;
          margin: auto;
          padding: 0 20px;
          background-color: #fff; /* Latar belakang putih untuk container */
        }

        /* Header */
        .news-header {
          background: white;
          padding: 15px 0;
          border-bottom: 1px solid #ddd;
        }

        .logo {
          float: left;
          height: 40px;
        }

        nav ul {
          list-style: none;
          display: flex;
          gap: 20px;
          float: left;
          align-items: center;
        }

        nav ul li a {
          text-decoration: none;
          color: #333;
          font-weight: 500;
        }
        nav ul li a.active {
          font-weight: bold;
          color: #ff6347;
        }

        .search-bar {
          float: right;
          display: flex;
          gap: 10px;
        }

        .search-bar input {
          padding: 8px;
          width: 250px;
          border-radius: 5px;
          border: 1px solid #ccc;
        }

        .search-bar button {
          padding: 8px 12px;
          background: #ff6347;
          color: white;
          border: none;
          border-radius: 5px;
          cursor: pointer;
        }

        /* Highlight Section */
        .highlight-section {
          background: white;
          padding: 40px 20px;
          margin-top: 80px; /* Jarak dari navbar */
        }

        .highlight-section h2 {
          font-size: 24px;
          margin-bottom: 20px;
          color: #333; /* Warna hitam untuk judul */
        }

        .highlight-container {
          display: flex;
          gap: 20px;
          flex-wrap: wrap;
        }

        .main-article img {
          width: 100%;
          border-radius: 8px;
          transition: transform 0.3s ease; /* Efek hover */
        }
        .main-article img:hover {
          transform: scale(1.1); /* Gambar maju saat hover */
        }

        .main-article h3 {
          margin: 15px 0 10px;
          font-size: 18px;
          color: #333; /* Warna hitam untuk subjudul */
        }

        .supporting-articles {
          display: flex;
          flex-direction: column;
          gap: 20px;
          flex: 1;
        }

        .supporting-article img {
          width: 100%;
          border-radius: 8px;
          transition: transform 0.3s ease; /* Efek hover */
        }
        .supporting-article img:hover {
          transform: scale(1.1); /* Gambar maju saat hover */
        }

        .supporting-article h4 {
          font-size: 14px;
          margin: 10px 0 5px;
          color: #333; /* Warna hitam untuk teks */
        }

        .source-date {
          color: #888;
          font-size: 12px;
        }

        /* You May Like Section */
        .you-may-like-section {
          background: white;
          padding: 40px 20px;
          margin-top: 20px;
        }

        .you-may-like-section h2 {
          font-size: 24px;
          margin-bottom: 20px;
          color: #333; /* Warna hitam untuk judul */
        }

        .you-may-like-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
          gap: 20px;
        }

        .recommendation-card img {
          width: 100%;
          border-radius: 8px;
          transition: transform 0.3s ease; /* Efek hover */
        }
        .recommendation-card img:hover {
          transform: scale(1.1); /* Gambar maju saat hover */
        }

        .recommendation-card h4 {
          font-size: 14px;
          margin: 10px 0 5px;
          color: #333; /* Warna hitam untuk teks */
        }

        .pagination {
          margin-top: 30px;
          text-align: center;
        }

        .pagination button {
          padding: 8px 15px;
          margin: 0 5px;
          border: 1px solid #ccc;
          background: white;
          cursor: pointer;
          border-radius: 5px;
        }

        .pagination button.active {
          background: #ff6347;
          color: white;
          border-color: #ff6347;
        }

        /* Action Button */
        .feedback-button {
          position: fixed;
          bottom: 30px;
          right: 30px;
          width: 50px;
          height: 50px;
          background: #ff6347;
          color: white;
          border: none;
          border-radius: 50%;
          font-size: 20px;
          cursor: pointer;
          z-index: 1000;
        }
      `}</style>

      {/* Section Highlight */}
      <section className="highlight-section">
        <h2>HIGHLIGHT</h2>
        <div className="highlight-container">
          <div className="main-article">
            <img src={mainArticle.image} alt={mainArticle.title} />
            <h3>{mainArticle.title}</h3>
            <p className="source-date">{mainArticle.source} • {mainArticle.date}</p>
          </div>
          <div className="supporting-articles">
            {supportingArticles.map((article) => (
              <div key={article.id} className="supporting-article">
                <img src={article.image} alt={article.title} />
                <h4>{article.title}</h4>
                <p className="source-date">{article.source} • {article.date}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section You May Like */}
      <section className="you-may-like-section">
        <h2>YOU MAY LIKE</h2>
        <div className="you-may-like-grid">
          {recommendedArticles.map((article) => (
            <div key={article.id} className="recommendation-card">
              <img src={article.image} alt={article.title} />
              <h4>{article.title}</h4>
              <p className="source-date">{article.source} • {article.date}</p>
            </div>
          ))}
        </div>
        {/* Pagination */}
        <div className="pagination">
          <button>Prev</button>
          <button className="active">1</button>
          <button>2</button>
          <button>Next</button>
        </div>
      </section>

      {/* Action Button */}
      <button className="feedback-button">💬</button>
    </div>
  );
};

export default NewsEventPage;